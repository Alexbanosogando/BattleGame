import contract from './AVAXGods.json';

export const ADDRESS = '0xC6825E381F728a0300f3FD1bf82d9B378FFD83eA';
export const { abi: ABI } = contract;
